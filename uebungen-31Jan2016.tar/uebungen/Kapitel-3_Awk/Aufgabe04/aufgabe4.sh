#!/bin/sh
# aufgabe4.sh
ls -l | awk '{
if(NF > 5)
{
	if($5 < 100) printf "%-20.20s ist KLEIN\n", $NF
	if($5 >= 100 && $5 <= 1000) printf "%-20.20s ist MITTEL\n", $NF
	if($5 > 1000) printf "%-20.20s ist GROSS\n", $NF
}
}'
