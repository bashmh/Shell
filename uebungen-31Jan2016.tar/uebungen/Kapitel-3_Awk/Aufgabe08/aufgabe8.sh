#!/bin/sh
# aufgabe8.sh

awk -F':' '
{namen[NR]=$1}
END{
for (i=1; i<=NR; i++){
        print namen[i]
}
}
' /etc/passwd
