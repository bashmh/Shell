#!/bin/sh
# aufgabe3.sh

echo "Benutzernummer groesser oder gleich 100 "
awk  -F: 'BEGIN { OFS = "\t" }
$3 >= 100 { print $1, $3 }' /etc/passwd

echo "Benutzernummer zwischen 0 und 99"
awk  -F: 'BEGIN { OFS = "\t" }
$3 > 0 && $3 < 99 { print $1, $3 }' /etc/passwd

# Pfad zur Korn-Shell muss ggf. angepasst werden
echo  "Verwenden nicht die Korn-shell"
awk  -F: 'BEGIN { OFS = "\t" }
$NF != "/bin/ksh" { print $1, $NF }' /etc/passwd

# Pfade zu den Shells muessen ggf. angepasst werden
echo  "Verwenden die Korn-shell oder die Bourne-Shell"
awk  -F: 'BEGIN { OFS = "\t" }
$NF == "/bin/ksh" || $NF == "/bin/sh" { print $1, $NF }' /etc/passwd
