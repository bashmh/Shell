#!/bin/sh
# aufgabe6.sh

awk '
# Zu Beginn wird die Gesamtsumme initialisiert
BEGIN { gesamtsumme=0 }
# Erste Zeile normal ausgeben
NR == 1
# Zweite Zeile ausgeben und Summe dahinter schreiben
# Anzahl Spalten werden fuer die Formatierung gespeichert
NR == 2 {
        spalten=NF
        for (i = 1; i <= NF; i++){
                printf("%10s", $i)
        }
        printf ("%10s\n", "Summe")
}
# Nach der 2. Zeile wird mit einer for-Schleife die Summe des Teilnehmers berechnet 
# und die Zeile mit der Summe ausgegeben
# Die Summe des Teilnehmers wird dann zur Gesamtsumme addiert
NR > 2 {
        summe=0
        for (i = 1; i <= spalten; i++){
                summe+=$i
                printf("%10s", $i)
        }
        printf ("%10s\n", summe)
        gesamtsumme+=summe
}
# Am Ende wird die Gesamtsumme formatiert ausgegeben
END { printf "Gesamtsumme:%48s\n", gesamtsumme }
' telefonabrechnung
