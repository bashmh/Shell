#!/bin/sh
# aufgabe5.sh

# For-Schleife
echo "-----------------------------------for-Schleife---------------------------------"
awk -F: '{
for (i = 1; i <= NF; i++)
{
        printf "%s ", $i
}
printf "\n"
}' /etc/passwd

# While-Schleife
echo "-----------------------------------while-Schleife--------------------------------"
awk -F: '{
i = 1
while( i <= NF)
{
        printf "%s ", $i
        i++
}
printf "\n"
}' /etc/passwd

# For-Schleife reverse
echo  "-------------------------------for-Schleife reverse ------------------------ "
awk -F: '{
for (i = NF; i >= 1; i--)
{
        printf "%s ", $i
}
printf "\n"
}' /etc/passwd

# While-Schleife reverse
echo "-----------------------------while-Schleife reverse---------------------------"
awk -F: '{
i = NF
while( i >= 1)
{
        printf "%s ", $i
        i--
}
printf "\n"
}' /etc/passwd
