#!/bin/sh
# aufgabe2.sh

echo "Benutzername und Startprogramm aus der Datei /etc/passwd"
awk  -F ':' '{ print $1,   $NF }' /etc/passwd

echo "Benutzername und Startprogramm aus der Datei /etc/passwd mit Tabulator als OFS"
awk  -F: 'BEGIN { OFS = "\t" }
{ print $1, $NF }' /etc/passwd

echo "Benutzername und Startprogramm aus der Datei /etc/passwd mit Tabulator als OFS und nummeriert"
awk  -F: 'BEGIN { OFS = "\t" }
{ print NR, $1, $NF }' /etc/passwd

echo "Benutzername und Startprogramm aus der Datei /etc/passwd mit Tabulator als OFS und nummeriert nur fuer Benutzer, die mit user beginnen"
awk  -F: 'BEGIN { OFS = "\t" }
/^user/ { print NR, $1, $NF }' /etc/passwd

echo "Benutzername und Startprogramm aus der Datei /etc/passwd mit Tabulator als OFS und nummeriert nur fuer die ersten 10 Accounts"
awk  -F: 'BEGIN { OFS = "\t" }
NR<=10 { print NR, $1, $NF }' /etc/passwd
