#!/bin/sh
# awkPreCompile2.sh

# Hier wird eine Datei angegeben, in die die Kommentare geschrieben werden
awk 'BEGIN { comment = "kommentare.out" }

# Leerzeilen werden nicht ausgegeben
/^$/ { next }

# Allgemeiner Block fuer alle Zeilen
{
        # 1. Feld startet mit #
        if(($1 ~ "^#"))
        {
                # #!/bin/sh Zeilen werden als NICHT Kommentarzeilen betrachtet
                if($1 ~ "^#!/")
                {
                        print $0
                }else # Alle anderen werden in die Kommentardatei geschrieben
                {
                        print "Zeile: ", NR, $0 >comment
                }
        }else # 1. Feld startet NICHT mit #
        {
                # Dann gucken wir ob es mittendrin ein # gibt
                for(i = 1; i <= NF; i++)
                {
                        # Kommentarzeilen mittendrin
                        # Das waere auch sowas bla#bla
                        if($i == "#" || $i ~ "^#")
                        {
                                # Ausgabe in die Kommentardattei
                                printf "Zeile: %d ", NR >comment
                                for(j = i; j <= NF; j++)
                                {
                                        printf "%s ", $j >comment
                                }
                                printf "\n" >comment
                                break
                        }
                        # Alles ohne Kommentar ausgeben
                        printf "%s ", $i
                }
                printf "\n"
        }
}' "$1"
