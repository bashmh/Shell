#!/bin/sh
# awkPreCompile.sh

awk '

# Leerzeilen werden nicht ausgegeben
/^$/ { next }

# Allgemeiner Block fuer alle Zeilen
{
        # 1. Feld startet mit #
        if(($1 ~ "^#"))
        {
                # #!/bin/sh Zeilen werden als NICHT Kommentarzeilen betrachtet
                if($1 ~ "^#!/")
                {
                        print $0
                }
        }else # 1. Feld startet NICHT mit #
        {
                # Dann gucken wir ob es mittendrin ein # gibt
                for(i = 1; i <= NF; i++)
                {
                        # Kommentarzeilen mittendrin
                        # Das waere auch sowas bla#bla
                        if($i == "#" || $i ~ "^#")
                        {
                                break
                        }
                        # Alles ohne Kommentar ausgeben
                        printf "%s ", $i
                }
                printf "\n"
        }
}' "$1"
