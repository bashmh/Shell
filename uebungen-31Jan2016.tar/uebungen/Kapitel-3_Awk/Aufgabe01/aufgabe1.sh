#!/bin/sh
# aufgabe1.sh
echo "Dateien des Arbeitsverzeichnisses und deren Groesse"
ls -l | awk  'NR==1 {next} {print $NF, $5 }'

echo "Benutzernummer, Gruppennummer sowie Benutzername aus der Datei /etc/passwd"
awk  -F ':' '{ print $3, $4, $1 }' /etc/passwd
