#!/bin/sh
# aufgabe9.sh

awk -F: '{
if($4 in groupnr)
{
        groupnr[$4]++
        groupmember[$4] = groupmember[$4] "," $1
}
else
{
        groupnr[$4] = 1
        groupmember[$4] = $1
}
}
END {
for (i in groupnr)
{
        printf "Gruppennummer : %4d, %3d Mitglieder\n", i, groupnr[i]
        if(i == 0)
        {
                printf "root::%d:%s\n", i, groupmember[i] >"myetcgroup"
        }
        else
        {
                printf "gruppe%d::%d:%s\n", i, i, groupmember[i] >"myetcgroup"
        }
}
close(myetcgroup)
}' /etc/passwd
