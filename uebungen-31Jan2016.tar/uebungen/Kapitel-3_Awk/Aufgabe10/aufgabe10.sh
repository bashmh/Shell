#!/bin/sh
# aufgabe10.sh

ls -l | awk '{
if(NF > 5)
{
        if($5 < 100) typ[$NF] = "KLEIN"
        if($5 >= 100 && $5 <= 1000) typ[$NF] = "MITTEL"
        if($5 > 1000) typ[$NF] = "GROSS"
}
}
END {
for(t in typ)
{
        if(typ[t] == "KLEIN")
                printf "%-7s %s\n", "KLEIN:", t
}
for(t in typ)
{
        if(typ[t] == "MITTEL")
                printf "%-7s %s\n", "MITTEL:", t
}
for(t in typ)
{
        if(typ[t] == "GROSS")
                printf "%-7s %s\n", "GROSS:", t
}
}'
