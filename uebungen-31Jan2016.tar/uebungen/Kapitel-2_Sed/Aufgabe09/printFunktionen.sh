#/bin/sh
#printFunktionen.sh
if [ "$#" -eq 1 -a -f "$1" ]
then
        sed -e 's/\([^#]*\)#.*/\1/' "$1" | sed -n -e 's/[         ]*\([A-Za-z].*\)().*/\1/p'
else
        echo "$0 gibt die Funktions-Namen von Shellskripten aus."
        echo "Als Argument wird der korrekte Name einer Skript-Datei erwartet."
fi
