#!/bin/sh
echo Beim ersten Mal kommt noch zuviel ...
echo ""
grep '#' $1 # Da kommt aber noch zuviel heraus also ....

echo ""
echo "Hier ist es schon besser"
echo ""
grep '#' $1 | grep -v '$#'      # Aber auch hier haben wir noch zuviel,
                                # naemlich echo "#####" ist kein Kommentar

echo ""
echo "jetzt ist es schon gut"
echo ""
grep '#' $1 | grep -v '$#' | egrep -v "\"[^\"]*#|'[^']*#"

echo ""
echo "und jetzt ist es fast alles"
echo ""
grep '#' $1 | grep -v '$#' | egrep -v "\"[^\"]*#|'[^']*#"  | grep -v '^#!/'
