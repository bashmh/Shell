#/bin/sh
#plattenkapazitaet.sh
# 1. Zeile 1 mit den Ueberschriften loeschen
# 2. Zeilen mit 0 KByte werden geloescht
# 3. Formatieren der Ausgabe. Zuerst der Einhaengepunkt dann Kapazitaet und dann freier Speicher
df -k | sed \
  -e '1 d' \
  -e '/ *0 *0 *0 *0%/d' \
  -e 's@^[^ ]\{1,\} \{1,\}\([1-9][0-9]*\) *[1-9][0-9]* *\([1-9][0-9]*\) .*% *\(/.*\)@\3 \1 \2@'
