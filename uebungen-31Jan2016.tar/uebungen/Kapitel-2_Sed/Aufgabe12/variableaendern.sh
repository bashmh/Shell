#/bin/sh
#variableaendern.sh
# Argumente:
# 1. Dateiname
# 2. Variablen-Name der zu ersetzen ist.
# 3. Variablen-Name der dafuer einzusetzen ist.
datei="$1"
istVar="$2"
sollVar="$3"

sed -e \
's/\([  ]\{1,\}\)\$'$istVar'\([         ]\{1,\}\)/\1$'$sollVar'\2/g' \
-e \
's/\([  ]\{1,\}\)\$'$istVar'$/\1$'$sollVar'/g' \
-e \
's/^\$'$istVar'\([      ]\{1,\}\)/$'$sollVar'\1/g' \
-e \
's/\([  ]*\)'$istVar'=/\1'$sollVar'=/g' \
$datei
