#>>> Definieren einer Funktion in awk
#>>> Aufruf im BEGIN Block und im allgemeinen Block

awk ' BEGIN { schreibe("Hallo")
schreibe("Helmut")
}
function schreibe(wert) { print wert }
{ schreibe("Peter") }' /etc/passwd | less

#>>> Anwendung von Standardfunktionen

awk -F: '
{ x=length($0); print x } ' /etc/passwd
awk -F: '
{ y=substr($0,1,10); print y } ' /etc/passwd
awk -F: '
{ y=index($0,"NTP"); print y } ' /etc/passwd
awk -F: '
{ y=sub(/NTP/,"AAA",$0); print $0 } ' /etc/passwd
awk -F: '
{ y=match($0,/NTP/); print y } ' /etc/passwd

#>>> Aufruf von Kommandos der Shell

awk ' BEGIN { system("ls") } '
touch /tmp/helmutdir
awk ' BEGIN { if (system("mkdir /tmp/helmutdir 2>/dev/null") !=0) { print "geht nicht" }} '

#>>> Variablen

env
awk ' BEGIN { print ENVIRON["TERM"] } '
awk ' BEGIN { for (env in ENVIRON) print env "=" ENVIRON[env] } '
x=$(awk ' BEGIN { for (env in ENVIRON) print env "=" ENVIRON[env] } ')
echo $x

#>>> Datei anlegen

awk ' BEGIN { x=100; print x > "/tmp/dateix" } '
ls -al /tmp/dateix

#>>> Ausgabe in Kommando pipen

awk ' BEGIN { x=100; print x | "wc -l" } '

#>>> Kommando einlesen

awk ' BEGIN { "who am i" | getline; print $1 } '
awk ' BEGIN { "who am i" | getline; name=$1; print name; FS=":" } name~$1 { print $6 } ' /etc/passwd
awk ' BEGIN { while ("who" | getline who_out[++i]); close("who"); for (i in who_out) print who_out[i]}'
awk ' BEGIN { while ("who" | getline who_out[++i]); close("who"); for (i in who_out) print who_out[i]; print who_out[1]; print who_out[2]; print who_out[3];}'







