#!/bin/bash
echo $$
trap 'clear; echo "und kann nicht unterbrochen werden - Signale 1 2 3 18 20"; echo ' 1 2 3 18 20
trap 'clear; echo "und kann doch unterbrochen werden - Signal 15"; exit 1' 15
#trap 'echo "Signal 19 eingegeben"' 19 
trap 'clear; echo 4 5 6 7 8 10 11 12 13 14 16 17; echo' 4 5 6 7 8 10 11 12 13 14 16 17
while true
do
	echo $$
	echo Ich bin in einer Schleife 
	echo Bitte Signale 1-20 eingeben 
	echo Bitte Signale 15 oder 9 eingeben 
	echo Nach Signal 19 bitte Signal 18 eingeben 
	echo  
	sleep 2	
done
