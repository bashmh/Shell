#!/bin/sh
#stillAlive2.sh
ps -Af | grep -v $$ | grep $1
