#!/bin/sh
#stillAlive.sh
ps -fp $1 || echo "Prozess nicht vorhanden"
