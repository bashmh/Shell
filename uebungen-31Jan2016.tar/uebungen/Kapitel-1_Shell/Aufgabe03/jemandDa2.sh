#!/bin/sh
#jemandDa2.sh
# nur wenn whoami vorhanden ist
who | cut -d ' ' -f 1 | grep -v `whoami` | sort | uniq
