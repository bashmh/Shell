#!/bin/sh
# cleanPATH.sh
echo '$PATH vorher'
echo "$PATH"
i=0
for eintrag in `echo $PATH | tr ':' ' '`
do
        # Diese Abfrage dient dazu, dass vor dem ersten Eintrag kein : steht
        if [ $i -eq 0 ]
        then
                test -d $eintrag && { newPATH="$eintrag"; i=1; continue; }
                echo "$eintrag wurde entfernt"
        else
                test -d $eintrag && { newPATH="$newPATH:$eintrag"; continue; }
                echo "$eintrag wurde entfernt"
        fi
done
PATH=$newPATH:
unset newPATH
echo '$PATH nachher'
echo $PATH
