#!/bin/sh
#wasWirdGetan.sh

if getopts 'u:' OPT
then
        case $OPT in
        u)      USERS="$OPTARG";;
        *)      echo "Gebrauch: $0 [-u <benutzername>]"
                exit 1;;
        esac
fi

if [ "$USERS" = "" ]
then
        USERS=`./jemandDa.sh`
fi

date
for benutzer in $USERS
do
        if [ $benutzer = "root" ]
        then
                echo ""
                echo "root arbeitet"
        else
                echo ""
                echo "Prozessliste fuer Benutzer $benutzer"
                ps -u $benutzer
        fi
done
