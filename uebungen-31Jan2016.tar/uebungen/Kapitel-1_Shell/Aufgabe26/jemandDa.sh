#!/bin/sh
#jemandDa.sh
who | cut -d ' ' -f 1 | grep -v $LOGNAME | sort -u
