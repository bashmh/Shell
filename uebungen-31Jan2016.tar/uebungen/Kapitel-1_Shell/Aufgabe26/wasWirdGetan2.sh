#!/bin/sh
#wasWirdGetan2.sh

USERS=""
while getopts 'u:' OPT
do
        case $OPT in
        u)      USERS="$USERS $OPTARG";;
        *)      echo "Gebrauch: $0 [-u <benutzername>]"
                exit 1;;
        esac
done

if [ "$USERS" = "" ]
then
        USERS=`./jemandDa.sh`
fi

date
for benutzer in $USERS
do
        if [ $benutzer = "root" ]
        then
                echo ""
                echo "root arbeitet"
        else
                echo ""
                echo "Prozessliste fuer Benutzer $benutzer"
                ps -u $benutzer
        fi
done
