#!/bin/sh
#machDB.sh
. ./funktionen

verzeichnis=$HOME
ausgabeDatei=$HOME/.db

dateiExist $ausgabeDatei && mv $ausgabeDatei ${ausgabeDatei}.sik
dateiCanCreate $ausgabeDatei && ls -a $verzeichnis > $ausgabeDatei
