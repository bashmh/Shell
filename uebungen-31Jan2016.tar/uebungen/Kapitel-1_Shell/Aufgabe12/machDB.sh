#!/bin/sh
#machDB.sh
. ./funktionen

dateiExist $HOME/.db && mv $HOME/.db $HOME/.db.sik
dateiCanCreate $HOME/.db && ls -a $HOME > $HOME/.db
