#!/bin/sh
#sucheDateiIn.sh
syntaxHelp()
{
        echo "$0 sucht eine Datei unterhalb eines gegebenen Verzeichnisses."
        echo "Syntax: sucheDateiIn [Datei] [Ordner]"
        echo "[Ordner] kann weggelassen werden. In diesem Fall wird das Arbeitsverzeichnis benutzt."
}

if [ $# -eq 0 ]
then
        syntaxHelp
        exit 1
fi

#       1 Parameter = Dateiname
#       2 Parameter = Verzeichnis
DATEI=${1:?"Als 1. Argument wird ein Dateiname erwartet."}
VERZ=${2:-`pwd`}

if [ -d "$VERZ" ]
then
        find "$VERZ" -name "$DATEI" 2>/dev/null
else
        echo "Das angegebene Verzeichnis $VERZ existiert nicht!"
        syntaxHelp
        exit 1
fi
