#!/bin/sh
#stillAlive.sh
# Defaultwert fuer das Intervall
INTERVALL=2

while getopts 't:' OPT
do
        case $OPT in
        t)      INTERVALL=$OPTARG
                expr $INTERVALL + 0 >/dev/null 2>&1 || { echo Fehler Argument nicht numerisch $INTERVALL; exit 1; }
                ;;
        *)      echo "Gebrauch: $0 [-t <zeitintervall>] prozessid"
                exit 2
                ;;
        esac
done

shift `expr $OPTIND - 1`

while ps -fp "$1"
do
        sleep $INTERVALL
done
echo "Prozess nicht vorhanden"
