#!/bin/sh
#stillAlive2.sh
INTERVALL=2

while getopts t: OPT
do
        case "$OPT" in
        t)      INTERVALL=$OPTARG       # Intervall ist Optionsargument
                expr $INTERVALL + 0 >/dev/null 2>&1 || { echo Fehler Argument nicht numerisch $INTERVALL; exit 1; }
                ;;
        *)      echo "Gebrauch: $0 [-t <zeitintervall>] prozess"
                exit 2
                ;;
        esac
done

shift `expr $OPTIND - 1`

while ps -Af | grep -v $$ | grep "$1"
do
        sleep $INTERVALL
done
echo "Prozess nicht vorhanden"
