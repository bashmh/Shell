#!/bin/sh
# pruefePATH2.sh
pruefePATH(){
    RC=0
    for PFAD in `echo $PATH | tr ':' ' '`
    do
	if [ ! -d $PFAD ]
	then
            echo "$PFAD ist kein Verzeichnis"
            RC=1
            break
        fi
    done
    return $RC
}
pruefePATH
