#!/bin/sh
# pruefePATH.sh
pruefePATH()
{
	# Standardrueckgabewert festlegen
	RC=0

	# Alle : durch ' ' Blanks ersetzen
	# Fuer jeden Pfadeintrag Schleife durchlaufen
	for eintrag in `echo $PATH | tr ':' ' '`
	do
		# Kein Verzeichnis, Ausgabe machen, Return Code setzen Schleife
		# verlassen
		test -d $eintrag || { echo $eintrag ist kein Verzeichnis; RC=1;
		break; }
	done
	return $RC
}
pruefePATH
