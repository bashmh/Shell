#!/bin/sh
#sucheDateiIn.sh
#       1 Parameter = Dateiname
#       2 Parameter = Verzeichnis
DATEI=${1:?"Als 1. Argument wird ein Dateiname erwartet."}
VERZ=${2:-`pwd`}

find "$VERZ" -name "$DATEI" 2>/dev/null -exec echo Datei {} gefunden \;
echo "ENDE"
