#!/bin/sh
#sucheDateiIn.sh
#       1 Parameter = Dateiname
#       2 Parameter = Verzeichnis
DATEI=${1:?"Als 1. Argument wird ein Dateiname erwartet."}
VERZ=${2:-`pwd`}
if [ -d "$VERZ" ]   # alternativ: if ls -ld "$VERZ" 2> /dev/null | grep '^d' 2> /dev/null >&2
then
        find "$VERZ" -name "$DATEI" 2>/dev/null -exec echo Datei {} gefunden \;
else
        echo "Das angegebene Verzeichnis $VERZ existiert nicht!"
        exit 1
fi
