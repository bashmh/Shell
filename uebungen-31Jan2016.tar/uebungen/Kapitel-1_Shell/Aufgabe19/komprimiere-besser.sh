#!/bin/sh
#komprimiere.sh
##for datei in "$*"
for datei in "$@"
do
##    compress -f `cat "$datei"`
    gzip `cat "$datei"`
done
