#!/bin/sh
#sucheDateiIn.sh
syntaxHelp()
{
        if [ "$LANG" = "de_DE" ]
        then
                echo "$0 sucht eine Datei unterhalb eines gegebenen Verzeichnisses."
                echo "Syntax: sucheDateiIn [Datei] [Ordner]"
                echo "[Ordner] kann weggelassen werden. In diesem Fall wird das Arbeitsverzeichnis benutzt."
        else
                echo "$0 searches a file below a given directory."
                echo "Syntax: sucheDateiIn [file] [directory]"
                echo "[directory] can be omitted. In this case the working directory is used."
        fi
}

verzeichnisFehler()
{
        if [ "$LANG" = "de_DE" ]
        then
                echo "Das angegebene Verzeichnis $VERZ existiert nicht!"
        else
                echo "The given directory $VERZ does not exist!"
        fi
}

if [ $# -eq 0 ]
then
        syntaxHelp
        exit 1
fi

#       1 Parameter = Dateiname
#       2 Parameter = Verzeichnis
DATEI=${1:?"Keine Datei angegeben"}
VERZ=${2:-`pwd`}

if [ -d "$DATEI" ]
then
        ls -ld "$DATEI"
else
        if [ -d "$VERZ" ]
        then
                find "$VERZ" -name "$DATEI" 2>/dev/null
        else
                verzeichnisFehler
                syntaxHelp
                exit 1
        fi
fi
