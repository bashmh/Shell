#!/bin/sh
#sucheDateiIn.sh
#	1 Parameter = Dateiname
#	2 Parameter = Verzeichnis
find "$2" -name "$1" 2>/dev/null
