#!/bin/sh
#stillAlive.sh
while ps -fp "$1"
do
        sleep 2
done
echo "Prozess nicht vorhanden"
