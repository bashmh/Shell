#!/bin/sh
#stillAlive.sh
while ps h -fp "$1"
do
        sleep 2
done
echo "Prozess nicht vorhanden"
