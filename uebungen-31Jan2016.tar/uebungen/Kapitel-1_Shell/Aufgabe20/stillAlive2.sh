#!/bin/sh
#stillAlive2.sh
while ps -Af | grep -v $$ | grep "$1"
do
	sleep 2
done
echo "Prozess nicht vorhanden"
