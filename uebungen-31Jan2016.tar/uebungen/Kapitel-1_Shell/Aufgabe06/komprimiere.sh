#!/bin/sh
#komprimiere.sh
compress -f `cat $1`
