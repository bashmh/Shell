#!/bin/sh
#komprimiere.sh
gzip `cat $1`
