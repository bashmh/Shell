#!/bin/sh
#wechsel.sh
cd /tmp
touch neu_$LOGNAME
