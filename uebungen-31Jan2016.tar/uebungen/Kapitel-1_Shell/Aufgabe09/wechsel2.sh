#!/bin/sh
#wechsel2.sh
cd /tmp
> neu_$LOGNAME
