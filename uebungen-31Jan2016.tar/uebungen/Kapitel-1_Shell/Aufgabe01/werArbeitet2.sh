#!/bin/sh
#werArbeitet2.sh
( who; date ) >werArbeitet.dat
