#!/bin/sh
#werArbeitet3.sh
{ who; date; } >werArbeitet.dat
