#!/bin/sh
#werArbeitet.sh
who >werArbeitet.dat
date >>werArbeitet.dat
