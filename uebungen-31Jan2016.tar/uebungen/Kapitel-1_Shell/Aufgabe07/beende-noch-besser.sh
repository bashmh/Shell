#!/bin/sh
#beende.sh
kill `ps -A | grep -w $1 | tr -s ' ' | sed 's/^ //' | cut -d ' ' -f 1`
