#!/bin/sh
#beende.sh
kill `ps -A | grep $1 | tr -s ' ' | cut -d ' ' -f 1`
