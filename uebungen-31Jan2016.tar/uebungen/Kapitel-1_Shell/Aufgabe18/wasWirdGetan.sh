#!/bin/sh
#wasWirdGetan.sh
date
for benutzer in `./jemandDa.sh`
do
        if [ "$benutzer" = "root" ]
        then
                echo ""
                echo "root arbeitet"
        else
                echo ""
                echo "Prozessliste fuer Benutzer $benutzer"
                ps -u $benutzer
        fi
done
