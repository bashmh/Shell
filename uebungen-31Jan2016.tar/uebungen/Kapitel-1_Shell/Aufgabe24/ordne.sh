#!/bin/sh
#ordne.sh
test -d texte || mkdir texte
test -d daten || mkdir daten
test -d bilder || mkdir bilder

for file in *
do
if [ -f "$file" ]
then
        case $file in
        *.txt)  mv "$file" texte && echo "$file wurde nach texte verschoben";;
        *.dat)  mv "$file" daten && echo "$file wurde nach daten verschoben";;
        *.bmp)  mv "$file" bilder && echo "$file wurde nach bilder verschoben";;
        *)      echo "$file ist ein unbekannter File Typ und wird nicht aufgeraeumt";;
        esac
fi
done
