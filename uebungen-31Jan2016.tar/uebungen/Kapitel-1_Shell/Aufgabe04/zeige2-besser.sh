#!/bin/sh
#zeige2.sh
test -f "$1" && more $1 || echo "Datei $1 nicht vorhanden"
