#!/bin/sh
#zeige.sh
ls $1 >/dev/null 2>&1 && less $1 || echo "Datei $1 nicht vorhanden"
