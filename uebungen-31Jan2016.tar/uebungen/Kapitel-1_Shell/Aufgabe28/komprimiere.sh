#!/bin/sh
#komprimiere.sh
##LISTE=$*
LISTE=$@
echo $LISTE

if [ "$LISTE" = "" ]
then
      echo "Bitte Liste(n) angeben:"
##      exec 3<&1
      exec 3<&0
      read LISTE <&3
      exec 3<&-
fi

echo $LISTE
for i in $LISTE
do
    gzip `cat $i`
done
