#!/bin/sh
#ccd.sh
i=1
for ordner in `find . -type d`
do
        echo "$i: $ordner"
        i=`expr $i + 1`
done
