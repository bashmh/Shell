#!/bin/sh
#uidVon.sh
grep "^$1:" /etc/passwd | cut -d : -f 3
