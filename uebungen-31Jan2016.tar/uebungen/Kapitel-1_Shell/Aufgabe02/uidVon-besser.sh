#!/bin/sh
#uidVon.sh
USAGE="$0 username"
if [[ $# -ne 1 ]]
then
echo "Proper usage: $USAGE"
exit 1
fi
#
grep "^$1:" /etc/passwd | cut -d : -f 3
