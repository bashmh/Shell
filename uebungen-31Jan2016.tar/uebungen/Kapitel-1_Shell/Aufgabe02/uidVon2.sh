#!/bin/sh
#uidVon2.sh
cat /etc/passwd | grep "^$1:" | cut -d : -f 3
