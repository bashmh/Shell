#!/bin/sh
#beende.sh

echo "Wollen Sie das Programm $1 wirklich beenden?(j/n)"
read antwort

if [ "$antwort" = "j" ]
then
##        kill `ps -A | grep $1 | tr -s ' ' | cut -d ' ' -f 2`
        kill `ps -A | grep -w $1 | tr -s ' ' | sed 's/^ //' | cut -d ' ' -f 1`
fi
