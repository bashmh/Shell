#!/bin/sh
#beende2.sh

antwort=""
while getopts 'q' OPT
do
        case $OPT in
        q)      antwort="j";;
        *)      echo "Gebrauch: $0 [-q]"
                exit 1
                ;;
        esac
done

shift `expr $OPTIND - 1`

if [ "$antwort" = "" ]
then
        echo "Wollen Sie das Programm $1 wirklich beenden?(j/n)"
        read antwort
fi

if [ "$antwort" = "j" ]
then
        kill `ps -A | grep -w $1 | tr -s ' ' | sed 's/^ //' | cut -d ' ' -f 1`
fi
