#!/bin/sh
#stillAliveS.sh
##trap 'PROZESSLISTE=`cat stillAliveS.conf`' 1
trap 'PROZESSLISTE=`cat stillAliveS.conf` ; echo " STRG+C wurde eingetippt" ' 2
PROZESSLISTE=`cat stillAliveS.conf`
while [ "$PROZESSLISTE" != "" ]
do
echo "Neue Prozessliste: $PROZESSLISTE"
cat -vte stillAliveS.conf
        for PROZESS in $PROZESSLISTE
        do
                ps h -fp $PROZESS || { echo "Prozess $PROZESS nicht vorhanden" ; cp stillAliveS.conf tmp$$ ; sed -e s/$PROZESS// tmp$$ | sed 's/^ *//' | sed 's/ *$//' > stillAliveS.conf ; }
        done
sleep 5
echo " "
done
