#!/bin/sh
#stillAliveS.sh
trap 'PROZESSLISTE=`cat stillAliveS.conf`' 1
PROZESSLISTE=`cat stillAliveS.conf`
while [ "$PROZESSLISTE" != "" ]
do
        for PROZESS in $PROZESSLISTE
        do
                ps -fp $PROZESS || echo "Prozess $PROZESS nicht vorhanden"
        done
sleep 5
done
