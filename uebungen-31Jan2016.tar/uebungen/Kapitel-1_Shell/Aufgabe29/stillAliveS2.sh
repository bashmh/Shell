#!/bin/sh
#stillAliveS2.sh
trap 'PROZESSLISTE=`cat stillAliveS.conf`' 1
PROZESSLISTE=`cat stillAliveS.conf`
while [ "$PROZESSLISTE" != "" ]
do
        for PROZESS in $PROZESSLISTE
        do
                ps -Af | grep -v $$ | grep $PROZESS || echo "Prozess $PROZESS nicht vorhanden"
        done
sleep 5
done
